package eecs1022.lab5;

/**
 * Created by mailh on 2018-03-19.
 */

public class tester {


    public static void main(String args[]) {


        Bank bank = new Bank();

        //CREATE ACCOUNT PART

        String ane = "nuiw";
        double am = -90;
        bank.addClinet(ane,am);
        System.out.println(bank.CreateAccountTostring());

        String name3 = "nuiw";
        double a = 9000;
        bank.addClinet(name3,a);
        System.out.println(bank.CreateAccountTostring());

        String name = "harsh";
        double balance = 1000;
        bank.addClinet(name,balance);
        System.out.println(bank.CreateAccountTostring());

        String name1 = "bran";
        double balanc = 500;
        bank.addClinet(name1, balanc);
        System.out.println(bank.CreateAccountTostring());

      // TRANSACTION PART

        String h1 = "harnsh";
        String h2 = "bran";
        String service = "TRANSFER";
        double b = 200;
        bank.Transaction(h2,h1,b,service);
        System.out.println(bank.toStringTranscation());
        bank.Transaction(h2,h1,b,service);
        System.out.println(bank.toStringTranscation());


        // OUTPUT STATEMENT


        System.out.println(bank.statement(h1));
        System.out.println(bank.statement(h2));
        System.out.println(bank.statement(name3));








    }
}